var isFemale = false;
var isOld = true;
// var isOldOrFemale = isOld || isFemale;
// alert(isOldOrFemale);
var isMale = ! isFemale;
alert(isMale);