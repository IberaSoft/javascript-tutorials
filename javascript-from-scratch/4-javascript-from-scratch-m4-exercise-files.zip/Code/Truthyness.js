var x = 5;
// var y = x < 10 ? x : 10;

var y;
if (x < 10)
{
  y = x;
}
else
{
  y = 10;
}
