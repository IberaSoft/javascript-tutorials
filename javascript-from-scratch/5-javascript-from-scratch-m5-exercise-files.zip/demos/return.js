
var add = function (x, y)
{
  var z = x + y;
  return;
  
};

var sum = add(5,6);

//alert(sum);
output.innerHTML = sum;











