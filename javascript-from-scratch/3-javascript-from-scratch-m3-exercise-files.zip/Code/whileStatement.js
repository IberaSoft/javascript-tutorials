var age = Number(prompt("What is your age? ", ""));

var string = "";
do 
{
    string += "Happy Birthday \n";
    age -= 1;
} while (age > 0)

alert(string);





