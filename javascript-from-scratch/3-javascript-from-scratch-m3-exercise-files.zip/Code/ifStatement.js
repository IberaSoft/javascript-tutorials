var ageAsString = prompt("What is your age? ", "");
var age = Number(ageAsString);
if ( age < 40 )
{
    alert("Oh you're so young...");
}

alert("Thank you");





