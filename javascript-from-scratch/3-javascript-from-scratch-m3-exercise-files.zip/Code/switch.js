// Code goes here

var animal = "dog";

switch (animal)
{
    case "cat":
        alert("meow");
        break;
    case "dog":
        alert("woof");
        break;
    case "horse":
        alert("whinny");
        break;
    default:
        alert ("Unknown animal!");
        break;
}