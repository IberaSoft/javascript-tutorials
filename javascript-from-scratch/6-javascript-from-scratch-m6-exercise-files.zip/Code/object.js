var dog = {
    name: "Charlie",
    breed: "Mix",
    weight: 12,
    color: "Brown"
    };

    var dogWeight = dog.weight;
    // alert(dogWeight);

    dog.disposition = "wonderful";

    var disp = dog.disposition;
    // alert(disp);

    var height = dog.height;
   // alert(height);

    dog.weight = 15;

    var dogWeight2 = dog.weight;
   // alert(dogWeight2);







